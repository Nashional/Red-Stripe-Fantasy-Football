
from django.db import models

# Create your models here.

class User(models.Model):
     name = models.CharField(max_length=255)
     team_number =  models.IntegerField()
     weekly_score  = models.IntegerField()
     total_score= models.IntegerField()
     balance = models.FloatField()
     password = models.CharField(max_length=94)
     email = models.CharField(max_length=255)
     user_name = models.CharField(max_length=255)
     profile_picture = models.CharField(max_length=255)
     created_at =  models.DateField()
     updated_at = models.DateField()

class Players(models.Model):
     name = models.CharField(max_length=255)
     league_team = models.CharField(max_length=255)
     score = models.FloatField()
     position = models.CharField(max_length=255)
     price = models.FloatField()