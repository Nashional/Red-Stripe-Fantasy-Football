from django.conf.urls import url 
from . import views

# register your views here.
urlpatterns = [ url(r'^$', views.index, name ='index'),
                url(r'^user/register/', views.register, name ='register'),  url(r'^user/create/', views.create_user, name ='create_user'),
                url(r'^team/formation/', views.select_formation, name ='select_formation') 
                ]